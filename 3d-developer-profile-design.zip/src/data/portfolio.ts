export interface Theme {
  id: string;
  name: string;
  bg: string;
  accent: string;
  secondary: string;
  tertiary: string;
  grid: string;
  glow: string;
  gradient: string;
}

export const themes: Theme[] = [
  {
    id: 'nebula',
    name: 'Nebula',
    bg: '#050014',
    accent: '#8b5cf6',
    secondary: '#06b6d4',
    tertiary: '#ec4899',
    grid: '#8b5cf6',
    glow: 'rgba(139,92,246,0.45)',
    gradient: 'from-violet-500 via-fuchsia-500 to-cyan-400',
  },
  {
    id: 'cyber',
    name: 'Cyber',
    bg: '#020617',
    accent: '#0ea5e9',
    secondary: '#22d3ee',
    tertiary: '#818cf8',
    grid: '#0ea5e9',
    glow: 'rgba(14,165,233,0.45)',
    gradient: 'from-sky-400 via-cyan-400 to-blue-600',
  },
  {
    id: 'matrix',
    name: 'Matrix',
    bg: '#010806',
    accent: '#22c55e',
    secondary: '#a3e635',
    tertiary: '#14b8a6',
    grid: '#22c55e',
    glow: 'rgba(34,197,94,0.4)',
    gradient: 'from-emerald-400 via-lime-400 to-teal-500',
  },
  {
    id: 'ember',
    name: 'Ember',
    bg: '#0f0205',
    accent: '#f97316',
    secondary: '#ec4899',
    tertiary: '#facc15',
    grid: '#f97316',
    glow: 'rgba(249,115,22,0.45)',
    gradient: 'from-orange-500 via-rose-500 to-amber-400',
  },
];

export const roles = [
  'Full-Stack Developer',
  'React & Node.js Engineer',
  '3D Web Enthusiast',
  'UI/UX Minded Developer',
  'Problem Solver & Fast Learner',
];

export const stats = [
  { value: 1, suffix: '', label: 'Year Experience' },
  { value: 5, suffix: '', label: 'Projects Shipped' },
  { value: 0, suffix: '', label: 'Happy Clients' },
  { value: 0, suffix: '', label: 'GitHub Commits' },
];

export const skills = [
  { name: 'React / Next.js', level: 96, icon: 'atom', color: '#61dafb', desc: 'SSR, RSC, performance tuning' },
  { name: 'TypeScript', level: 94, icon: 'braces', color: '#3178c6', desc: 'Strict typing, generics, tooling' },
  { name: 'Three.js / R3F', level: 92, icon: 'box', color: '#8b5cf6', desc: 'Shaders, physics, WebGL UX' },
  { name: 'Node.js / Bun', level: 90, icon: 'server', color: '#22c55e', desc: 'APIs, queues, realtime' },
  { name: 'Tailwind / Motion', level: 95, icon: 'palette', color: '#06b6d4', desc: 'Design systems, animation' },
  { name: 'Python / AI', level: 82, icon: 'brain', color: '#facc15', desc: 'LLMs, RAG, agents' },
];

export const techStack = [
  'React', 'TypeScript', 'Three.js', 'Next.js', 'Node.js', 'Tailwind CSS',
  'Framer Motion', 'PostgreSQL', 'GraphQL', 'Docker', 'AWS', 'Blender',
  'GSAP', 'Prisma', 'Redis', 'Figma',
];

/* ============================================================
   FEATURED PROJECTS — central place for all project content.
   To replace a preview, simply drop your screenshot at the
   `image` path inside /public  (e.g. /public/images/projects/fonzy-topup.png)
   and it will automatically replace the designed placeholder.
   ============================================================ */
export interface FeaturedProject {
  id: number;
  title: string;
  category: string;
  description: string;
  image: string; // ← replace with your real screenshot at this path
  tags: string[];
  year: string;
  type: string;
  link: string;
  demo: string;
  group: 'web' | 'trading' | 'mobile';
  visual: 'topup' | 'trading' | 'community' | 'planner' | 'grocery';
  gradient: string;
  accent: string;
  featured: boolean;
}

export const featuredProjects: FeaturedProject[] = [
  {
    id: 1,
    title: 'Fonzy_Pirate Top-up Game',
    category: 'Web App / E-commerce',
    description:
      'A Cambodia-focused game top-up platform designed for digital game products, game top-ups, product browsing, checkout and KHQR payment integration.',
    image: '/images/projects/fonzy-topup.png',
    tags: ['React', 'WebApp', 'KHQR', 'Firebase'],
    year: '2026',
    type: 'Personal Project',
    link: '#',
    demo: '#',
    group: 'web',
    visual: 'topup',
    gradient: 'from-violet-600 via-indigo-600 to-cyan-500',
    accent: '#22d3ee',
    featured: true,
  },
  {
    id: 2,
    title: 'Day Flow — Apex Trading',
    category: 'Trading / Web App',
    description:
      'A premium trading education and trader-development platform focused on market structure, risk management, psychology, analysis, trading journey and community.',
    image: '/images/projects/dayflow-trading.png',
    tags: ['Trading', 'MarketAnalysis', 'RiskManagement', 'WebApp'],
    year: '2026',
    type: 'Personal Project',
    link: '#',
    demo: '#',
    group: 'trading',
    visual: 'trading',
    gradient: 'from-emerald-500 via-teal-500 to-cyan-500',
    accent: '#34d399',
    featured: true,
  },
  {
    id: 3,
    title: 'Market Community App',
    category: 'Social / Market Analysis',
    description:
      'A social community platform combining trader discussions, groups, channels, market viewing, charts and real-time community interaction.',
    image: '/images/projects/market-community.png',
    tags: ['SocialApp', 'Trading', 'Community', 'Charts'],
    year: '2026',
    type: 'Personal Project',
    link: '#',
    demo: '#',
    group: 'trading',
    visual: 'community',
    gradient: 'from-green-500 via-emerald-500 to-lime-500',
    accent: '#4ade80',
    featured: false,
  },
  {
    id: 4,
    title: 'Daily Planner',
    category: 'Productivity / Mobile Web App',
    description:
      'A personal productivity application for daily planning, habits, goals, reminders, journal entries, notes, saving-money notes and daily reflection.',
    image: '/images/projects/daily-planner.png',
    tags: ['Productivity', 'Planner', 'Journal', 'MobileApp'],
    year: '2026',
    type: 'Personal Project',
    link: '#',
    demo: '#',
    group: 'mobile',
    visual: 'planner',
    gradient: 'from-amber-400 via-orange-500 to-rose-500',
    accent: '#fbbf24',
    featured: false,
  },
  {
    id: 5,
    title: 'FreshCart',
    category: 'E-commerce / Mobile Web App',
    description:
      'A modern mobile-first grocery shopping experience with product browsing, categories, search, cart, checkout, order tracking and profile features.',
    image: '/images/projects/freshcart.png',
    tags: ['HTML', 'CSS', 'JavaScript', 'Ecommerce'],
    year: '2026',
    type: 'Personal Project',
    link: '#',
    demo: '#',
    group: 'mobile',
    visual: 'grocery',
    gradient: 'from-lime-400 via-green-500 to-emerald-600',
    accent: '#a3e635',
    featured: false,
  },
];

export const experience = [
  {
    period: '2025 — Present',
    role: 'Junior Full-Stack Developer',
    company: 'Freelance & Personal Projects · Battambang',
    description: 'Building complete web apps end-to-end with React, Node.js, Express and PostgreSQL — 5 projects shipped including dashboards and an e-commerce demo. Open for my first professional role.',
    tags: ['React', 'Node.js', 'PostgreSQL'],
    current: true,
  },
  {
    period: '2024 — 2025',
    role: 'Web Development Trainee',
    company: 'Full-Stack Bootcamp · Battambang',
    description: 'Intensive training in JavaScript, REST APIs, databases, Git and agile teamwork. Shipped a team capstone project and graduated with honors.',
    tags: ['JavaScript', 'REST API', 'Teamwork'],
    current: false,
  },
  {
    period: '2022 — 2024',
    role: 'Information Technology Student',
    company: 'University in Battambang',
    description: 'Learned programming fundamentals, networking, databases, OOP and web basics. Built my first websites and small tools for classmates.',
    tags: ['C++', 'Java', 'HTML/CSS'],
    current: false,
  },
];

export const services = [
  { icon: 'globe', title: 'Immersive Websites', desc: 'Award-level marketing sites with 3D, motion & storytelling.' },
  { icon: 'app', title: 'Web Applications', desc: 'Scalable SaaS dashboards, realtime apps & design systems.' },
  { icon: 'cube', title: '3D & WebGL', desc: 'Product configurators, metaverse scenes & shader effects.' },
  { icon: 'zap', title: 'Performance & AI', desc: 'Core Web Vitals, SEO & LLM integration for smart UX.' },
];
