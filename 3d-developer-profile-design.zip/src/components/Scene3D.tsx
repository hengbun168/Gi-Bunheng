import { useMemo, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Stars, Sparkles, Float, Grid, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';
import type { Theme } from '../data/portfolio';

interface SceneProps {
  theme: Theme;
  autoRotate: boolean;
  showParticles: boolean;
  speed: number;
}

function CameraRig({ speed }: { speed: number }) {
  useFrame((state, delta) => {
    const { pointer, camera, clock } = state;
    const t = clock.elapsedTime * 0.15 * speed;
    // gentle drift + mouse parallax
    const targetX = pointer.x * 2.2 + Math.sin(t) * 0.4;
    const targetY = pointer.y * 1.4 + Math.cos(t * 0.8) * 0.3;
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, targetX, delta * 1.2);
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, targetY, delta * 1.2);
    camera.lookAt(0, 0, 0);
  });
  return null;
}

function ParticleField({ count, color, color2, speed }: { count: number; color: string; color2: string; speed: number }) {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = 6 + Math.random() * 14;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      arr[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      arr[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.7;
      arr[i * 3 + 2] = r * Math.cos(phi);
    }
    return arr;
  }, [count]);

  const colors = useMemo(() => {
    const c1 = new THREE.Color(color);
    const c2 = new THREE.Color(color2);
    const arr = new Float32Array(count * 3);
    const tmp = new THREE.Color();
    for (let i = 0; i < count; i++) {
      tmp.copy(c1).lerp(c2, Math.random());
      arr[i * 3] = tmp.r;
      arr[i * 3 + 1] = tmp.g;
      arr[i * 3 + 2] = tmp.b;
    }
    return arr;
  }, [count, color, color2]);

  useFrame((_, delta) => {
    if (ref.current) {
      ref.current.rotation.y += delta * 0.03 * speed;
      ref.current.rotation.x += delta * 0.008 * speed;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.08}
        vertexColors
        transparent
        opacity={0.85}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
}

function CoreShape({ theme, autoRotate, speed }: { theme: Theme; autoRotate: boolean; speed: number }) {
  const group = useRef<THREE.Group>(null);
  const knot = useRef<THREE.Mesh>(null);
  const wire = useRef<THREE.Mesh>(null);
  const ring1 = useRef<THREE.Mesh>(null);
  const ring2 = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    const t = state.clock.elapsedTime;
    const s = autoRotate ? speed : 0.15;
    if (knot.current) {
      knot.current.rotation.x += delta * 0.25 * s;
      knot.current.rotation.y += delta * 0.32 * s;
    }
    if (wire.current) {
      wire.current.rotation.x -= delta * 0.12 * s;
      wire.current.rotation.y -= delta * 0.18 * s;
    }
    if (ring1.current) ring1.current.rotation.z += delta * 0.2 * s;
    if (ring2.current) ring2.current.rotation.z -= delta * 0.15 * s;
    if (group.current) {
      const isMobile = window.innerWidth < 1024;
      const scroll = Math.min(window.scrollY / window.innerHeight, 4);
      // Base position: right side on desktop, center-back on mobile
      const baseX = isMobile ? 0 : 3.6;
      const baseY = isMobile ? 1.4 : 0.2;
      const baseZ = isMobile ? -4.5 : -1.5;
      // On scroll, drift toward center and further back for readability
      const targetX = THREE.MathUtils.lerp(baseX, 0, Math.min(scroll * 0.5, 0.85));
      const targetY = baseY + Math.sin(t * 0.5) * 0.3 - scroll * 0.4;
      const targetZ = baseZ - scroll * 0.6;
      group.current.position.x = THREE.MathUtils.lerp(group.current.position.x, targetX, 0.06);
      group.current.position.y = THREE.MathUtils.lerp(group.current.position.y, targetY, 0.06);
      group.current.position.z = THREE.MathUtils.lerp(group.current.position.z, targetZ, 0.06);
      const baseScale = isMobile ? 0.62 : 1;
      const scale = baseScale * (1 - Math.min(scroll * 0.08, 0.3));
      group.current.scale.setScalar(scale);
    }
  });

  return (
    <group ref={group} position={[3.6, 0.2, -1.5]}>
      {/* Main distorted orb */}
      <Float speed={2} rotationIntensity={0.6} floatIntensity={0.9}>
        <mesh ref={knot}>
          <torusKnotGeometry args={[1.35, 0.38, 220, 36]} />
          <MeshDistortMaterial
            color={theme.accent}
            emissive={theme.accent}
            emissiveIntensity={0.35}
            roughness={0.15}
            metalness={0.9}
            distort={0.32}
            speed={2.2 * speed}
          />
        </mesh>
      </Float>

      {/* Wireframe shell */}
      <mesh ref={wire}>
        <icosahedronGeometry args={[2.55, 1]} />
        <meshBasicMaterial color={theme.secondary} wireframe transparent opacity={0.28} />
      </mesh>

      {/* Glow core */}
      <mesh>
        <sphereGeometry args={[0.55, 32, 32]} />
        <meshBasicMaterial color={theme.secondary} transparent opacity={0.9} />
      </mesh>
      <pointLight color={theme.secondary} intensity={8} distance={12} decay={2} />

      {/* Orbit rings */}
      <mesh ref={ring1} rotation={[Math.PI / 2.4, 0.3, 0]}>
        <torusGeometry args={[3.4, 0.02, 16, 120]} />
        <meshBasicMaterial color={theme.secondary} transparent opacity={0.6} />
      </mesh>
      <mesh ref={ring2} rotation={[Math.PI / 1.8, -0.4, 0.2]}>
        <torusGeometry args={[4, 0.015, 16, 120]} />
        <meshBasicMaterial color={theme.tertiary} transparent opacity={0.4} />
      </mesh>
    </group>
  );
}

function FloatingShapes({ theme, speed }: { theme: Theme; speed: number }) {
  const group = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (group.current) group.current.rotation.y += delta * 0.05 * speed;
  });

  return (
    <group ref={group}>
      <Float speed={3} floatIntensity={1.4} position={[-4.5, 1.6, -2]}>
        <mesh>
          <octahedronGeometry args={[0.55]} />
          <meshStandardMaterial color={theme.accent} metalness={0.8} roughness={0.2} emissive={theme.accent} emissiveIntensity={0.4} />
        </mesh>
      </Float>
      <Float speed={2.2} floatIntensity={1.1} position={[-5.2, -1.8, -1]}>
        <mesh>
          <boxGeometry args={[0.7, 0.7, 0.7]} />
          <meshStandardMaterial color={theme.secondary} metalness={0.7} roughness={0.25} wireframe />
        </mesh>
      </Float>
      <Float speed={2.8} floatIntensity={1.2} position={[-2.8, 2.6, -3.5]}>
        <mesh>
          <torusGeometry args={[0.4, 0.14, 16, 40]} />
          <meshStandardMaterial color={theme.tertiary} metalness={0.85} roughness={0.2} emissive={theme.tertiary} emissiveIntensity={0.5} />
        </mesh>
      </Float>
      <Float speed={1.8} floatIntensity={0.9} position={[0.5, -2.8, -2.5]}>
        <mesh>
          <dodecahedronGeometry args={[0.5]} />
          <meshStandardMaterial color={theme.secondary} metalness={0.6} roughness={0.3} emissive={theme.accent} emissiveIntensity={0.3} />
        </mesh>
      </Float>
      <Float speed={2.5} floatIntensity={1} position={[-6.5, 0.4, -5]}>
        <mesh>
          <icosahedronGeometry args={[0.9, 0]} />
          <meshStandardMaterial color={theme.accent} wireframe transparent opacity={0.5} />
        </mesh>
      </Float>
    </group>
  );
}

function SceneContent({ theme, autoRotate, showParticles, speed }: SceneProps) {
  return (
    <>
      <color attach="background" args={[theme.bg]} />
      <fog attach="fog" args={[theme.bg, 10, 26]} />
      <ambientLight intensity={0.5} />
      <pointLight position={[6, 4, 4]} color={theme.accent} intensity={40} distance={20} />
      <pointLight position={[-6, -3, 2]} color={theme.secondary} intensity={30} distance={20} />
      <pointLight position={[0, 5, -4]} color={theme.tertiary} intensity={20} distance={18} />

      <Stars radius={60} depth={40} count={2200} factor={4} saturation={0.6} fade speed={0.6 * speed} />
      {showParticles && <ParticleField count={900} color={theme.accent} color2={theme.secondary} speed={speed} />}
      <Sparkles count={90} scale={[18, 10, 10]} size={3} speed={0.35 * speed} color={theme.secondary} opacity={0.6} position={[0, 0, -2]} />

      <CoreShape theme={theme} autoRotate={autoRotate} speed={speed} />
      <FloatingShapes theme={theme} speed={speed} />

      <Grid
        position={[0, -4.2, 0]}
        args={[40, 40]}
        cellSize={0.7}
        cellThickness={0.6}
        cellColor={theme.grid}
        sectionSize={3.5}
        sectionThickness={1.2}
        sectionColor={theme.accent}
        fadeDistance={24}
        fadeStrength={2.5}
        followCamera={false}
        infiniteGrid
      />
      <CameraRig speed={speed} />
    </>
  );
}

export default function Scene3D(props: SceneProps) {
  return (
    <div className="fixed inset-0 -z-10" style={{ background: props.theme.bg, transition: 'background 1s ease' }}>
      <Canvas
        dpr={[1, 1.75]}
        camera={{ position: [0, 0, 11.5], fov: 48 }}
        gl={{ antialias: true, alpha: false, powerPreference: 'high-performance' }}
      >
        <SceneContent {...props} />
      </Canvas>
      {/* vignette + fade for readability */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.45)_100%)]" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/60" />
    </div>
  );
}
