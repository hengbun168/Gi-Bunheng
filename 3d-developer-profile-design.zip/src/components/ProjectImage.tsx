import { useState } from 'react';
import {
  Gamepad2, QrCode, ShoppingCart, Gem, CandlestickChart,
  TrendingUp, Users, MessageCircle, CheckSquare, Bell, NotebookPen,
  Apple, Carrot, Milk, Search, ImageIcon,
} from 'lucide-react';
import type { FeaturedProject } from '../data/portfolio';

/* ------------------------------------------------------------------ */
/* Designed placeholder visuals — unique mockup per project.           */
/* When you add a real screenshot at the project's `image` path,       */
/* it replaces this automatically.                                     */
/* ------------------------------------------------------------------ */

function Candles() {
  const candles = [
    [20, 34, 14, 40, 'up'], [26, 22, 18, 30, 'down'], [30, 46, 28, 52, 'up'],
    [40, 34, 30, 44, 'down'], [36, 58, 34, 64, 'up'], [50, 44, 40, 56, 'down'],
    [46, 66, 44, 74, 'up'], [60, 54, 50, 66, 'down'], [56, 80, 54, 88, 'up'],
    [74, 68, 62, 78, 'down'], [70, 90, 66, 96, 'up'], [86, 80, 74, 92, 'down'],
    [82, 104, 78, 112, 'up'], [100, 94, 88, 108, 'down'], [96, 118, 92, 124, 'up'],
  ] as const;
  return (
    <svg viewBox="0 0 240 150" className="h-full w-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="candleLine" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#22d3ee" />
          <stop offset="100%" stopColor="#4ade80" />
        </linearGradient>
      </defs>
      {[30, 60, 90, 120].map((y) => (
        <line key={y} x1="0" y1={y} x2="240" y2={y} stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
      ))}
      {candles.map((c, i) => {
        const x = 10 + i * 15;
        const up = c[4] === 'up';
        const color = up ? '#4ade80' : '#f87171';
        return (
          <g key={i}>
            <line x1={x} y1={c[1]} x2={x} y2={c[3]} stroke={color} strokeWidth="1.5" />
            <rect x={x - 4} y={c[0]} width="8" height={Math.abs(c[2] - c[0])} rx="1.5" fill={color} opacity={up ? 0.95 : 0.8} />
          </g>
        );
      })}
      <path
        d="M10,120 C40,110 60,95 90,86 S150,60 180,48 S225,28 232,20"
        fill="none"
        stroke="url(#candleLine)"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

function Visual({ project }: { project: FeaturedProject }) {
  const v = project.visual;
  const base = 'relative flex h-full w-full flex-col overflow-hidden';

  if (v === 'topup') {
    return (
      <div className={`${base} bg-[#0b0a1f]`}>
        <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 80% 0%, rgba(124,58,237,0.45), transparent 55%), radial-gradient(circle at 0% 100%, rgba(6,182,212,0.35), transparent 50%)' }} />
        {/* fake browser chrome */}
        <div className="relative flex items-center gap-1.5 border-b border-white/10 bg-white/[0.03] px-4 py-2.5">
          <span className="h-2.5 w-2.5 rounded-full bg-rose-400/80" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber-300/80" />
          <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/80" />
          <span className="font-mono ml-3 rounded-md bg-white/5 px-3 py-1 text-[9px] text-white/50">fonzy-pirate.topup.com</span>
        </div>
        <div className="relative flex flex-1 gap-3 p-4">
          {/* sidebar */}
          <div className="hidden w-24 flex-col gap-2 sm:flex">
            <div className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-violet-600/80 to-indigo-600/80 px-2.5 py-2 text-[9px] font-bold text-white">
              <Gamepad2 className="h-3 w-3" /> FONZY
            </div>
            {['Top-up', 'Products', 'Orders', 'Account'].map((t, i) => (
              <div key={t} className={`rounded-lg px-2.5 py-2 text-[9px] ${i === 0 ? 'bg-white/10 text-white' : 'text-white/40'}`}>{t}</div>
            ))}
            <div className="mt-auto flex items-center gap-1.5 rounded-lg border border-emerald-400/30 bg-emerald-400/10 px-2 py-2 text-[8px] font-bold text-emerald-300">
              <QrCode className="h-3 w-3" /> KHQR
            </div>
          </div>
          {/* grid */}
          <div className="flex-1">
            <div className="mb-2 flex items-center justify-between">
              <div className="text-[10px] font-bold text-white/90">🎯 Game Top-ups</div>
              <div className="flex items-center gap-1 rounded-full bg-white/5 px-2 py-1 text-[8px] text-white/50"><Search className="h-2.5 w-2.5" /> Search</div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { e: '💎', n: 'Diamonds', p: '$0.99', c: 'from-sky-500/30 to-cyan-500/20' },
                { e: '🪙', n: 'Coins', p: '$1.99', c: 'from-amber-500/30 to-orange-500/20' },
                { e: '🎮', n: 'Pass', p: '$4.99', c: 'from-violet-500/30 to-fuchsia-500/20' },
                { e: '⚔️', n: 'Bundle', p: '$9.99', c: 'from-rose-500/30 to-pink-500/20' },
                { e: '🏴‍☠️', n: 'Pirate', p: '$2.49', c: 'from-indigo-500/30 to-blue-500/20' },
                { e: '🎁', n: 'Gift', p: '$0.49', c: 'from-emerald-500/30 to-teal-500/20' },
              ].map((g) => (
                <div key={g.n} className={`rounded-xl border border-white/10 bg-gradient-to-br ${g.c} p-2`}>
                  <div className="flex h-7 items-center justify-center rounded-lg bg-black/30 text-base">{g.e}</div>
                  <div className="mt-1.5 text-[8px] font-semibold text-white/80">{g.n}</div>
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-bold text-cyan-300">{g.p}</span>
                    <ShoppingCart className="h-2.5 w-2.5 text-white/40" />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-2.5 flex items-center justify-between rounded-xl border border-emerald-400/25 bg-emerald-400/10 px-3 py-2">
              <span className="flex items-center gap-1.5 text-[9px] font-bold text-emerald-300"><QrCode className="h-3 w-3" /> Pay with KHQR</span>
              <span className="rounded-md bg-emerald-400 px-2 py-0.5 text-[8px] font-bold text-emerald-950">Checkout →</span>
            </div>
          </div>
        </div>
        <div className="absolute top-1/2 right-3 -translate-y-1/2 opacity-20"><Gem className="h-20 w-20 text-cyan-300" /></div>
      </div>
    );
  }

  if (v === 'trading') {
    return (
      <div className={`${base} bg-[#050d12]`}>
        <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 20% 0%, rgba(16,185,129,0.28), transparent 55%), radial-gradient(circle at 90% 100%, rgba(34,211,238,0.25), transparent 50%)' }} />
        <div className="relative flex items-center justify-between border-b border-white/10 bg-white/[0.03] px-4 py-2.5">
          <div className="flex items-center gap-2">
            <div className="flex h-6 w-6 items-center justify-center rounded-md bg-gradient-to-br from-emerald-400 to-teal-600"><CandlestickChart className="h-3.5 w-3.5 text-emerald-950" /></div>
            <span className="text-[10px] font-black tracking-widest text-white">DAY FLOW · APEX</span>
          </div>
          <div className="hidden gap-3 text-[8px] font-semibold text-white/50 sm:flex">
            <span className="rounded bg-white/10 px-2 py-1 text-emerald-300">Structure</span>
            <span className="px-1 py-1">Risk</span><span className="px-1 py-1">Psychology</span>
          </div>
        </div>
        <div className="relative flex flex-1 gap-3 p-4">
          <div className="flex-1 rounded-xl border border-white/10 bg-black/30 p-2.5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[8px] uppercase tracking-wider text-white/40">XAU/USD · M15</div>
                <div className="text-sm font-black text-emerald-400">2,341.80 <span className="text-[8px] text-emerald-400">▲ +1.24%</span></div>
              </div>
              <div className="flex gap-1">
                {['1H', '4H', '1D'].map((t, i) => (
                  <span key={t} className={`rounded px-1.5 py-0.5 text-[7px] font-bold ${i === 1 ? 'bg-emerald-400/20 text-emerald-300' : 'text-white/40'}`}>{t}</span>
                ))}
              </div>
            </div>
            <div className="mt-1 h-[110px]"><Candles /></div>
            <div className="mt-1 flex items-center gap-2">
              <span className="flex items-center gap-1 rounded-md bg-emerald-400/15 px-2 py-1 text-[8px] font-bold text-emerald-300"><TrendingUp className="h-2.5 w-2.5" /> BUY 2,342.0</span>
              <span className="rounded-md bg-rose-400/15 px-2 py-1 text-[8px] font-bold text-rose-300">SELL</span>
              <span className="ml-auto text-[8px] text-white/40">R:R 1:3</span>
            </div>
          </div>
          <div className="hidden w-28 flex-col gap-2 sm:flex">
            <div className="rounded-xl border border-white/10 bg-black/30 p-2.5">
              <div className="text-[8px] uppercase tracking-wider text-white/40">Risk Score</div>
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full w-[68%] rounded-full bg-gradient-to-r from-emerald-400 to-cyan-400" /></div>
              <div className="mt-1 text-[10px] font-black text-emerald-300">68 / 100</div>
            </div>
            <div className="rounded-xl border border-white/10 bg-black/30 p-2.5">
              <div className="text-[8px] uppercase tracking-wider text-white/40">Journey</div>
              <div className="mt-1 space-y-1">
                {['Mindset ✓', 'Journal ✓', 'Backtest', 'Funded'].map((s, i) => (
                  <div key={s} className="flex items-center gap-1.5 text-[8px] text-white/60"><span className={`h-1.5 w-1.5 rounded-full ${i < 2 ? 'bg-emerald-400' : 'bg-white/20'}`} />{s}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (v === 'community') {
    return (
      <div className={`${base} bg-[#04100a]`}>
        <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 85% 10%, rgba(34,197,94,0.3), transparent 55%), radial-gradient(circle at 10% 100%, rgba(21,128,61,0.35), transparent 50%)' }} />
        <div className="relative flex flex-1 gap-3 p-4">
          {/* channels */}
          <div className="hidden w-24 flex-col gap-1.5 rounded-xl border border-white/10 bg-black/30 p-2.5 sm:flex">
            <div className="flex items-center gap-1.5 text-[9px] font-black text-emerald-300"><Users className="h-3 w-3" /> MARKET</div>
            {['# general', '# gold-talk', '# signals', '# setups', '🎙 voice'].map((c, i) => (
              <div key={c} className={`truncate rounded-md px-2 py-1.5 text-[8px] ${i === 1 ? 'bg-emerald-400/15 text-emerald-200' : 'text-white/45'}`}>{c}</div>
            ))}
          </div>
          {/* chat */}
          <div className="flex flex-1 flex-col rounded-xl border border-white/10 bg-black/30 p-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-[9px] font-bold text-white/80"># gold-talk · 1,240 online</span>
              <span className="flex -space-x-1.5">
                {['bg-emerald-400', 'bg-cyan-400', 'bg-lime-400', 'bg-teal-300'].map((c) => (
                  <span key={c} className={`h-4 w-4 rounded-full ${c} ring-2 ring-black`} />
                ))}
              </span>
            </div>
            <div className="mt-2 space-y-2">
              <div className="flex gap-2">
                <span className="h-5 w-5 shrink-0 rounded-full bg-emerald-400" />
                <div><div className="text-[8px] font-bold text-emerald-300">Sokha <span className="text-white/30">09:41</span></div>
                  <div className="mt-0.5 w-fit rounded-lg rounded-tl-none bg-white/10 px-2 py-1 text-[8px] text-white/75">Bullish structure on XAU? 🟢</div></div>
              </div>
              <div className="flex gap-2">
                <span className="h-5 w-5 shrink-0 rounded-full bg-cyan-400" />
                <div><div className="text-[8px] font-bold text-cyan-300">Dara <span className="text-white/30">09:43</span></div>
                  <div className="mt-0.5 w-fit rounded-lg rounded-tl-none bg-emerald-400/15 px-2 py-1 text-[8px] text-emerald-100">Waiting for retest of 2,338 👀</div></div>
              </div>
            </div>
            {/* mini chart */}
            <div className="mt-auto rounded-lg border border-white/10 bg-black/40 p-2">
              <div className="flex h-12"><Candles /></div>
            </div>
            <div className="mt-2 flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1.5 text-[8px] text-white/35">
              <MessageCircle className="h-2.5 w-2.5" /> Message #gold-talk…
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (v === 'planner') {
    return (
      <div className={`${base} items-center justify-center bg-[#140d06] p-4`}>
        <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 50% 0%, rgba(251,191,36,0.25), transparent 55%), radial-gradient(circle at 50% 100%, rgba(244,63,94,0.18), transparent 50%)' }} />
        <div className="relative flex h-full w-full max-w-[190px] flex-col rounded-[26px] border-4 border-white/15 bg-[#1c1408] p-3 shadow-2xl">
          <div className="mx-auto mb-2 h-1 w-8 rounded-full bg-white/20" />
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[7px] uppercase tracking-wider text-amber-300/70">Today</div>
              <div className="text-[12px] font-black text-white">My Day ✨</div>
            </div>
            <div className="relative flex h-9 w-9 items-center justify-center rounded-full">
              <svg viewBox="0 0 36 36" className="h-9 w-9 -rotate-90"><circle cx="18" cy="18" r="15" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="4" /><circle cx="18" cy="18" r="15" fill="none" stroke="#fbbf24" strokeWidth="4" strokeDasharray="70 100" strokeLinecap="round" /></svg>
              <span className="absolute text-[7px] font-black text-amber-300">70%</span>
            </div>
          </div>
          <div className="mt-2 space-y-1.5">
            {[['Morning workout', true], ['Read 20 pages', true], ['Deep work 3h', false], ['Save 5,000៛', false]].map(([t, done]) => (
              <div key={t as string} className="flex items-center gap-1.5 rounded-lg bg-white/5 px-2 py-1.5">
                <span className={`flex h-3 w-3 items-center justify-center rounded-[4px] ${done ? 'bg-amber-400 text-amber-950' : 'border border-white/25'}`}>{done ? <CheckSquare className="h-2 w-2" /> : null}</span>
                <span className={`text-[8px] ${done ? 'text-white/40 line-through' : 'text-white/80'}`}>{t}</span>
              </div>
            ))}
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <div className="rounded-lg bg-orange-400/10 p-2"><NotebookPen className="h-3 w-3 text-orange-300" /><div className="mt-1 text-[7px] font-bold text-white/80">Journal</div></div>
            <div className="rounded-lg bg-rose-400/10 p-2"><Bell className="h-3 w-3 text-rose-300" /><div className="mt-1 text-[7px] font-bold text-white/80">Reminders</div></div>
          </div>
          <div className="mt-1.5 rounded-lg border border-dashed border-white/15 p-2 text-[7px] text-amber-200/60">💰 Savings note: 120,000៛ this month</div>
        </div>
      </div>
    );
  }

  /* grocery / FreshCart */
  return (
    <div className={`${base} items-center justify-center bg-[#07120a] p-4`}>
      <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 50% 0%, rgba(163,230,53,0.22), transparent 55%), radial-gradient(circle at 50% 100%, rgba(34,197,94,0.2), transparent 50%)' }} />
      <div className="relative flex h-full w-full max-w-[190px] flex-col rounded-[26px] border-4 border-white/15 bg-[#0c1a10] p-3 shadow-2xl">
        <div className="mx-auto mb-2 h-1 w-8 rounded-full bg-white/20" />
        <div className="flex items-center justify-between">
          <div><div className="text-[12px] font-black text-lime-300">FreshCart 🛒</div><div className="text-[7px] text-white/40">Deliver in 30 min</div></div>
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-lime-400/15"><ShoppingCart className="h-3.5 w-3.5 text-lime-300" /></div>
        </div>
        <div className="mt-2 flex items-center gap-1.5 rounded-full bg-white/5 px-2.5 py-1.5 text-[8px] text-white/35"><Search className="h-2.5 w-2.5" /> Search groceries…</div>
        <div className="mt-2 flex gap-1.5">
          {['🥦 Veg', '🍎 Fruit', '🥛 Dairy'].map((c, i) => (
            <span key={c} className={`rounded-full px-2 py-1 text-[7px] font-bold ${i === 0 ? 'bg-lime-400 text-lime-950' : 'bg-white/5 text-white/55'}`}>{c}</span>
          ))}
        </div>
        <div className="mt-2 grid grid-cols-2 gap-1.5">
          {[
            { i: <Apple className="h-4 w-4 text-rose-300" />, n: 'Apples', p: '$1.20', c: 'from-rose-500/20' },
            { i: <Carrot className="h-4 w-4 text-orange-300" />, n: 'Carrots', p: '$0.80', c: 'from-orange-500/20' },
            { i: <Milk className="h-4 w-4 text-sky-200" />, n: 'Milk 1L', p: '$1.50', c: 'from-sky-500/20' },
            { i: <span className="text-sm">🥬</span>, n: 'Lettuce', p: '$0.60', c: 'from-lime-500/20' },
          ].map((p) => (
            <div key={p.n} className={`rounded-xl border border-white/10 bg-gradient-to-br ${p.c} to-transparent p-2`}>
              <div className="flex h-7 items-center justify-center rounded-lg bg-black/25">{p.i}</div>
              <div className="mt-1 text-[8px] font-bold text-white/85">{p.n}</div>
              <div className="flex items-center justify-between"><span className="text-[8px] font-black text-lime-300">{p.p}</span><span className="flex h-4 w-4 items-center justify-center rounded-full bg-lime-400 text-[9px] font-black text-lime-950">+</span></div>
            </div>
          ))}
        </div>
        <div className="mt-2 flex items-center justify-between rounded-xl bg-gradient-to-r from-lime-400 to-green-500 px-3 py-2 text-[8px] font-black text-green-950">
          <span>3 items · $3.50</span><span>Checkout →</span>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export default function ProjectImage({
  project,
  className = '',
}: {
  project: FeaturedProject;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);

  return (
    <div className={`group/img relative h-full w-full overflow-hidden ${className}`}>
      {/* Real screenshot if the file exists, otherwise designed placeholder */}
      {!failed ? (
        <img
          src={project.image}
          alt={`${project.title} preview`}
          loading="lazy"
          onError={() => setFailed(true)}
          className="h-full w-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-110"
        />
      ) : (
        <div className="h-full w-full transition-transform duration-700 ease-out group-hover:scale-105">
          <Visual project={project} />
        </div>
      )}

      {/* replacement hint (visible on hover) — tells you exactly which file to add */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex translate-y-full items-center gap-1.5 bg-black/70 px-3 py-1.5 font-mono text-[9px] text-white/70 backdrop-blur-sm transition-transform duration-300 group-hover/img:translate-y-0">
        <ImageIcon className="h-3 w-3" />
        {failed ? `add screenshot → ${project.image.replace('/images/', '')}` : project.image.replace('/images/', '')}
      </div>
    </div>
  );
}
