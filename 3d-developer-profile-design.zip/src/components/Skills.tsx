import { motion } from 'framer-motion';
import { Atom, Braces, Box, Server, Palette, Brain, BadgeCheck } from 'lucide-react';
import SectionHeading from './SectionHeading';
import { skills, techStack, type Theme } from '../data/portfolio';

const iconMap: Record<string, any> = {
  atom: Atom, braces: Braces, box: Box, server: Server, palette: Palette, brain: Brain,
};

export default function Skills({ theme }: { theme: Theme }) {
  return (
    <section id="skills" className="relative scroll-mt-24 py-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHeading
          theme={theme}
          index="02"
          eyebrow="Skills & Stack"
          title={<>My <span className="text-gradient">superpowers</span></>}
          desc="My growing toolkit, sharpened across 1 year of intensive learning and 5 shipped projects — from responsive UI to Node.js APIs."
        />

        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {skills.map((skill, i) => {
            const Icon = iconMap[skill.icon] ?? Braces;
            return (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.6, delay: (i % 3) * 0.1 }}
                className="glass card-shine group rounded-3xl p-6 transition-all duration-300 hover:-translate-y-1.5 hover:bg-white/[0.08]"
              >
                <div className="flex items-start justify-between">
                  <div
                    className="flex h-13 w-13 items-center justify-center rounded-2xl p-3.5"
                    style={{ background: `${skill.color}18`, border: `1px solid ${skill.color}40` }}
                  >
                    <Icon className="h-6 w-6" style={{ color: skill.color }} />
                  </div>
                  <span className="font-mono text-sm font-bold" style={{ color: skill.color }}>{skill.level}%</span>
                </div>
                <h3 className="font-display mt-4 text-lg font-bold">{skill.name}</h3>
                <p className="mt-1 text-sm text-white/50">{skill.desc}</p>
                <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.2, delay: 0.2 + (i % 3) * 0.1, ease: [0.22, 1, 0.36, 1] }}
                    className="h-full rounded-full"
                    style={{ background: `linear-gradient(90deg, ${skill.color}, ${theme.secondary})`, boxShadow: `0 0 12px ${skill.color}` }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* marquee */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="relative mt-12 overflow-hidden"
        >
          <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#050014] to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#050014] to-transparent" />
          <div className="flex w-max animate-[marquee_28s_linear_infinite] gap-3 hover:[animation-play-state:paused]">
            {[...techStack, ...techStack].map((t, i) => (
              <span
                key={i}
                className="glass flex shrink-0 items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium whitespace-nowrap transition-colors hover:bg-white/10"
              >
                <BadgeCheck className="h-4 w-4" style={{ color: theme.secondary }} />
                {t}
              </span>
            ))}
          </div>
        </motion.div>

        {/* tools strip */}
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {[
            { k: 'Design', v: 'Figma · Blender · Spline · After Effects' },
            { k: 'DevOps', v: 'Docker · AWS · Vercel · GitHub Actions' },
            { k: 'Data & AI', v: 'PostgreSQL · Redis · OpenAI · LangChain' },
          ].map((row, i) => (
            <motion.div
              key={row.k}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass flex items-center gap-4 rounded-2xl px-5 py-4"
            >
              <span className={`font-mono rounded-lg bg-gradient-to-r ${theme.gradient} px-3 py-1 text-[11px] font-bold tracking-widest uppercase`}>
                {row.k}
              </span>
              <span className="text-sm text-white/60">{row.v}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
