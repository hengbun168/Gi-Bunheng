import { motion } from 'framer-motion';
import type { Theme } from '../data/portfolio';

export default function SectionHeading({
  theme, index, eyebrow, title, desc,
}: { theme: Theme; index: string; eyebrow: string; title: React.ReactNode; desc?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="mb-12"
    >
      <div className="flex items-center gap-3">
        <span className="font-mono text-sm" style={{ color: theme.secondary }}>{index}</span>
        <span className="h-px w-10" style={{ background: theme.secondary }} />
        <span className="font-mono text-xs tracking-[0.3em] uppercase text-white/60">{eyebrow}</span>
      </div>
      <h2 className="font-display mt-4 text-4xl font-bold tracking-tight sm:text-5xl">{title}</h2>
      {desc && <p className="mt-4 max-w-2xl leading-relaxed text-white/55">{desc}</p>}
    </motion.div>
  );
}
