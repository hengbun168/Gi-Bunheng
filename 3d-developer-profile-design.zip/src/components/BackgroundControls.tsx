import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings2, X, RotateCw, Sparkles, Gauge } from 'lucide-react';
import { themes, type Theme } from '../data/portfolio';

interface Props {
  theme: Theme;
  setTheme: (t: Theme) => void;
  autoRotate: boolean;
  setAutoRotate: (v: boolean) => void;
  showParticles: boolean;
  setShowParticles: (v: boolean) => void;
  speed: number;
  setSpeed: (v: number) => void;
}

export default function BackgroundControls(props: Props) {
  const [open, setOpen] = useState(false);
  const { theme, setTheme } = props;

  return (
    <div className="fixed right-5 bottom-5 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="glass-strong w-[280px] rounded-3xl p-5 shadow-2xl"
          >
            <div className="mb-4 flex items-center justify-between">
              <h4 className="font-display text-sm font-bold tracking-wide">✨ 3D BACKGROUND</h4>
              <button
                onClick={() => setOpen(false)}
                className="flex h-7 w-7 items-center justify-center rounded-full bg-white/5 transition-colors hover:bg-white/15"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>

            <p className="font-mono mb-2.5 text-[11px] tracking-widest uppercase text-white/40">Universe theme</p>
            <div className="grid grid-cols-4 gap-2">
              {themes.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTheme(t)}
                  className="group flex flex-col items-center gap-1.5"
                >
                  <span
                    className={`h-10 w-10 rounded-full transition-all duration-300 ${
                      theme.id === t.id ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-black' : 'hover:scale-105 opacity-70 hover:opacity-100'
                    }`}
                    style={{ background: `linear-gradient(135deg, ${t.accent}, ${t.secondary}, ${t.tertiary})`, boxShadow: theme.id === t.id ? `0 0 20px ${t.glow}` : 'none' }}
                  />
                  <span className={`text-[10px] font-medium ${theme.id === t.id ? 'text-white' : 'text-white/40'}`}>{t.name}</span>
                </button>
              ))}
            </div>

            <div className="mt-4 space-y-2.5">
              <button
                onClick={() => props.setAutoRotate(!props.autoRotate)}
                className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-medium transition-colors hover:bg-white/10"
              >
                <span className="flex items-center gap-2">
                  <RotateCw className="h-3.5 w-3.5" style={{ color: theme.secondary }} />
                  Auto-rotate core
                </span>
                <span className={`relative h-5 w-9 rounded-full transition-colors ${props.autoRotate ? '' : 'bg-white/15'}`}
                  style={props.autoRotate ? { background: theme.accent } : undefined}>
                  <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${props.autoRotate ? 'left-[18px]' : 'left-0.5'}`} />
                </span>
              </button>
              <button
                onClick={() => props.setShowParticles(!props.showParticles)}
                className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-medium transition-colors hover:bg-white/10"
              >
                <span className="flex items-center gap-2">
                  <Sparkles className="h-3.5 w-3.5" style={{ color: theme.secondary }} />
                  Particle field
                </span>
                <span className={`relative h-5 w-9 rounded-full transition-colors ${props.showParticles ? '' : 'bg-white/15'}`}
                  style={props.showParticles ? { background: theme.accent } : undefined}>
                  <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${props.showParticles ? 'left-[18px]' : 'left-0.5'}`} />
                </span>
              </button>
            </div>

            <div className="mt-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="flex items-center gap-2 text-xs font-medium">
                  <Gauge className="h-3.5 w-3.5" style={{ color: theme.secondary }} />
                  Motion speed
                </span>
                <span className="font-mono text-xs" style={{ color: theme.secondary }}>{props.speed.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min={0.2}
                max={2.5}
                step={0.1}
                value={props.speed}
                onChange={(e) => props.setSpeed(parseFloat(e.target.value))}
                className="w-full accent-violet-500"
                style={{ accentColor: theme.accent }}
              />
            </div>

            <p className="font-mono mt-4 text-center text-[10px] text-white/30">
              Move your mouse — the universe follows ✨
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setOpen(!open)}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        className={`flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br ${theme.gradient} shadow-2xl`}
        style={{ boxShadow: `0 12px 40px ${theme.glow}` }}
        aria-label="Background settings"
      >
        <motion.span animate={{ rotate: open ? 90 : 0 }} transition={{ duration: 0.3 }}>
          {open ? <X className="h-6 w-6" /> : <Settings2 className="h-6 w-6 animate-[spin_6s_linear_infinite]" />}
        </motion.span>
      </motion.button>
    </div>
  );
}
