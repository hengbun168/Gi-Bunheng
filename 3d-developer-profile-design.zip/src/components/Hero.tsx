import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  MapPin, Download,
  ArrowDown, Sparkles, Code2, Boxes, ChevronRight
} from 'lucide-react';
import Avatar from './Avatar';

const GithubIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18" {...props}><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.19 1.76 1.19 1.03 1.75 2.69 1.25 3.34.95.1-.75.4-1.25.72-1.54-2.55-.29-5.23-1.28-5.23-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11 11 0 0 1 5.8 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.83 1.19 3.09 0 4.41-2.69 5.38-5.25 5.67.41.35.77 1.05.77 2.12 0 1.53-.01 2.76-.01 3.14 0 .3.2.67.8.55A11.51 11.51 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5Z"/></svg>
);
const LinkedinIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18" {...props}><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29ZM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12ZM7.12 20.45H3.55V9h3.57v11.45Z"/></svg>
);
const XIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18" {...props}><path d="M18.9 1.15h3.68l-8.04 9.19L24 22.85h-7.41l-5.8-7.58-6.64 7.58H.47l8.6-9.83L0 1.15h7.59l5.25 6.93 6.06-6.93Zm-1.29 19.5h2.04L6.49 3.24H4.3l13.31 17.41Z"/></svg>
);
const DribbbleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" width="18" height="18" {...props}><circle cx="12" cy="12" r="10"/><path d="M19.13 5.09C15.22 9.14 10 10.44 2.25 10.94M21.75 12.84c-6.62-1.41-12.14 1-16.38 6.32M8.56 2.75c4.37 6 6 9.42 8.03 17.72"/></svg>
);
import { roles, stats, type Theme } from '../data/portfolio';

function useTypewriter(words: string[]) {
  const [text, setText] = useState('');
  const [index, setIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = words[index % words.length];
    const speed = deleting ? 32 : 68;
    const timeout = setTimeout(() => {
      if (!deleting) {
        setText(word.slice(0, text.length + 1));
        if (text.length + 1 === word.length) {
          setTimeout(() => setDeleting(true), 1600);
        }
      } else {
        setText(word.slice(0, text.length - 1));
        if (text.length === 0) {
          setDeleting(false);
          setIndex((index + 1) % words.length);
        }
      }
    }, speed);
    return () => clearTimeout(timeout);
  }, [text, deleting, index, words]);

  return text;
}

function Counter({ value, suffix }: { value: number; suffix: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf: number;
    const start = performance.now();
    const dur = 1800;
    const tick = (t: number) => {
      const p = Math.min((t - start) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(Math.round(value * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    const timer = setTimeout(() => { raf = requestAnimationFrame(tick); }, 600);
    return () => { clearTimeout(timer); cancelAnimationFrame(raf); };
  }, [value]);
  return <span>{n}{suffix}</span>;
}

export default function Hero({ theme }: { theme: Theme }) {
  const typed = useTypewriter(roles);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const handleTilt = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 16;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -16;
    setTilt({ x, y });
  };

  return (
    <section id="home" className="relative flex min-h-screen items-center overflow-hidden pt-28 pb-16">
      <div className="grid-overlay pointer-events-none absolute inset-0" />
      {/* giant background text */}
      <div className="pointer-events-none absolute top-1/2 left-0 -translate-y-1/2 select-none overflow-hidden whitespace-nowrap opacity-[0.05]">
        <div className="font-display text-[22vw] leading-none font-bold tracking-tighter">DEVELOPER</div>
      </div>

      <div className="relative z-10 mx-auto grid w-full max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-[1.15fr_0.85fr]">
        {/* LEFT */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass mb-6 inline-flex items-center gap-2.5 rounded-full py-2 pr-5 pl-2"
          >
            <span className={`flex items-center gap-1 rounded-full bg-gradient-to-r ${theme.gradient} px-3 py-1 text-[11px] font-bold tracking-wider uppercase`}>
              <Sparkles className="h-3 w-3" /> New
            </span>
            <span className="font-mono text-xs text-white/70">Available for freelance & full-time · 2026</span>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="font-mono mb-3 text-sm tracking-[0.3em] uppercase"
            style={{ color: theme.secondary }}
          >
            👋 Hello world, I'm
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="font-display text-5xl leading-[1.02] font-bold tracking-tight sm:text-6xl xl:text-7xl"
          >
            Gi Bunheng
            <span className="text-gradient block pb-2">Full-Stack</span>
            <span className="block">Developer</span>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="font-mono mt-5 flex h-8 items-center text-base sm:text-lg"
          >
            <span style={{ color: theme.accent }} className="mr-2">{'>'}</span>
            <span className="text-white/90">{typed}</span>
            <span className="caret-blink ml-1 inline-block h-5 w-[2px]" style={{ background: theme.secondary }} />
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="mt-4 max-w-xl leading-relaxed text-white/60"
          >
            I build complete, reliable products from database to pixel — crafting modern
            web apps with <span className="text-white font-medium">React, Node.js & Three.js</span>,
            with a sharp eye for design. Based in Battambang, shipping worldwide.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }}
            className="mt-8 flex flex-wrap items-center gap-4"
          >
            <a
              href="#work"
              className={`group flex items-center gap-2 rounded-full bg-gradient-to-r ${theme.gradient} px-7 py-3.5 text-sm font-bold tracking-wide shadow-xl transition-transform hover:scale-105 active:scale-95`}
              style={{ boxShadow: `0 12px 40px ${theme.glow}` }}
            >
              VIEW MY WORK
              <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#contact"
              className="glass group flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold tracking-wide transition-all hover:bg-white/10"
            >
              <Download className="h-4 w-4" />
              DOWNLOAD CV
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-8 flex items-center gap-4"
          >
            {[
              { icon: GithubIcon, label: 'GitHub' },
              { icon: LinkedinIcon, label: 'LinkedIn' },
              { icon: XIcon, label: 'Twitter' },
              { icon: DribbbleIcon, label: 'Dribbble' },
            ].map((s) => (
              <a
                key={s.label}
                href="#home"
                aria-label={s.label}
                className="glass flex h-11 w-11 items-center justify-center rounded-full text-white/70 transition-all duration-300 hover:-translate-y-1 hover:text-white"
                onMouseEnter={(e) => { e.currentTarget.style.borderColor = theme.accent; e.currentTarget.style.boxShadow = `0 8px 24px ${theme.glow}`; }}
                onMouseLeave={(e) => { e.currentTarget.style.borderColor = ''; e.currentTarget.style.boxShadow = ''; }}
              >
                <s.icon className="h-[18px] w-[18px]" />
              </a>
            ))}
            <div className="font-mono ml-2 hidden items-center gap-1.5 text-xs text-white/40 sm:flex">
              <MapPin className="h-3.5 w-3.5" /> Battambang · Remote worldwide
            </div>
          </motion.div>

          {/* stats */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.6 }}
            className="mt-10 grid max-w-xl grid-cols-2 gap-3 sm:grid-cols-4"
          >
            {stats.map((s) => (
              <div key={s.label} className="glass card-shine rounded-2xl p-4 text-center">
                <div className="font-display text-2xl font-bold" style={{ color: theme.secondary }}>
                  <Counter value={s.value} suffix={s.suffix} />
                </div>
                <div className="mt-1 text-[11px] tracking-wide text-white/50 uppercase">{s.label}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* RIGHT — profile card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="perspective-1000 relative mx-auto w-full max-w-[380px]"
        >
          {/* orbit ring */}
          <div className="animate-spin-slow pointer-events-none absolute -inset-8 rounded-full border border-dashed border-white/10" />
          <div
            className="pointer-events-none absolute -inset-8 rounded-full opacity-30 blur-3xl"
            style={{ background: `radial-gradient(circle, ${theme.glow} 0%, transparent 70%)` }}
          />

          <div
            onMouseMove={handleTilt}
            onMouseLeave={() => setTilt({ x: 0, y: 0 })}
            className="preserve-3d glass-strong relative overflow-hidden rounded-[28px] p-2 shadow-2xl transition-transform duration-200 ease-out"
            style={{ transform: `rotateY(${tilt.x}deg) rotateX(${tilt.y}deg)` }}
          >
            <div className="relative overflow-hidden rounded-[22px]">
              <div className="h-[380px] w-full">
                <Avatar />
              </div>
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
              {/* top badges */}
              <div className="absolute top-4 right-4 left-4 flex items-center justify-between">
                <span className="glass flex items-center gap-1.5 rounded-full px-3 py-1.5 font-mono text-[11px] text-emerald-300">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                  ONLINE
                </span>
                <span className="glass rounded-full px-3 py-1.5 font-mono text-[11px] text-white/80">Year 1 · Full-Stack</span>
              </div>
              {/* bottom info */}
              <div className="absolute right-5 bottom-5 left-5">
                <div className="flex items-end justify-between">
                  <div>
                    <h3 className="font-display text-2xl font-bold">Gi Bunheng</h3>
                    <p className="font-mono text-xs" style={{ color: theme.secondary }}>Full-Stack Developer</p>
                  </div>
                  <div className={`flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br ${theme.gradient} shadow-lg`}>
                    <Code2 className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-3 flex gap-2">
                  {['React', 'Three.js', 'TypeScript'].map((t) => (
                    <span key={t} className="glass rounded-full px-3 py-1 text-[11px] font-medium">{t}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* card footer */}
            <div className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-2 font-mono text-xs text-white/60">
                <Boxes className="h-4 w-4" style={{ color: theme.secondary }} />
                5 projects shipped
              </div>
              <div className="flex items-center gap-1 text-xs text-emerald-300">
                <span>🌱</span> hungry to learn
              </div>
            </div>
          </div>

          {/* floating chips */}
          <motion.div
            animate={{ y: [0, -12, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            className="glass-strong absolute -left-2 top-16 flex items-center gap-2 rounded-2xl px-4 py-3 shadow-xl sm:-left-6"
          >
            <span className="text-xl">🚀</span>
            <div className="leading-tight">
              <div className="text-xs font-bold">Full-Stack Dev</div>
              <div className="font-mono text-[10px] text-white/50">End-to-end builds</div>
            </div>
          </motion.div>
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
            className="glass-strong absolute -right-2 bottom-24 flex items-center gap-2 rounded-2xl px-4 py-3 shadow-xl sm:-right-4"
          >
            <span className="text-xl">🧩</span>
            <div className="leading-tight">
              <div className="text-xs font-bold">Node.js APIs</div>
              <div className="font-mono text-[10px] text-white/50">REST · GraphQL · DB</div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* scroll hint */}
      <motion.a
        href="#about"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4 }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-white/40 transition-colors hover:text-white md:flex"
      >
        <span className="font-mono text-[10px] tracking-[0.3em] uppercase">Scroll to explore</span>
        <span className="glass flex h-10 w-6 items-start justify-center rounded-full p-1.5">
          <motion.span
            animate={{ y: [0, 12, 0], opacity: [1, 0.2, 1] }}
            transition={{ duration: 1.8, repeat: Infinity }}
            className="h-2 w-1 rounded-full"
            style={{ background: theme.secondary }}
          />
        </span>
        <ArrowDown className="h-3 w-3 animate-bounce" />
      </motion.a>
    </section>
  );
}
