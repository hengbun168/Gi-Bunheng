import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ExternalLink, ArrowUpRight, Rocket, FolderGit2, CalendarDays, PlayCircle, UserRound } from 'lucide-react';
import SectionHeading from './SectionHeading';
import ProjectImage from './ProjectImage';
import { featuredProjects, type FeaturedProject, type Theme } from '../data/portfolio';

const filters = [
  { id: 'all', label: 'All' },
  { id: 'web', label: 'Web App' },
  { id: 'trading', label: 'Trading' },
  { id: 'mobile', label: 'Mobile' },
] as const;

function ProjectCard({ project, theme, large, index }: { project: FeaturedProject; theme: Theme; large: boolean; index: number }) {
  return (
    <motion.article
      layout
      initial={{ opacity: 0, scale: 0.94, y: 28 }}
      whileInView={{ opacity: 1, scale: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55, delay: (index % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className="glass-strong group flex flex-col overflow-hidden rounded-[22px] transition-all duration-300 hover:-translate-y-2"
      onMouseEnter={(e) => { e.currentTarget.style.boxShadow = `0 24px 70px ${theme.glow}`; }}
      onMouseLeave={(e) => { e.currentTarget.style.boxShadow = ''; }}
    >
      {/* 1 — Large image at top of the card */}
      <div className="relative p-2 pb-0">
        <div className={`relative w-full overflow-hidden rounded-2xl ${large ? 'h-56 sm:h-64 lg:h-72' : 'h-44 sm:h-48'}`}>
          <ProjectImage project={project} />
          <div className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10" />
          {/* category chip */}
          <span className={`absolute top-3 left-3 rounded-full bg-gradient-to-r ${project.gradient} px-3 py-1 text-[10px] font-bold tracking-wide uppercase text-white shadow-lg backdrop-blur-sm`}>
            {project.category}
          </span>
          {/* year chip */}
          <span className="glass-strong absolute top-3 right-3 flex items-center gap-1 rounded-full px-2.5 py-1 font-mono text-[10px] font-bold text-white/85">
            <CalendarDays className="h-3 w-3" style={{ color: project.accent }} />
            {project.year}
          </span>
        </div>
      </div>

      {/* body */}
      <div className="flex flex-1 flex-col p-5 sm:p-6">
        {/* 2 — title */}
        <h3 className={`font-display font-bold leading-tight ${large ? 'text-2xl' : 'text-lg'}`}>
          {project.title}
        </h3>

        {/* 3 — description */}
        <p className={`mt-2 leading-relaxed text-white/55 ${large ? 'text-[15px]' : 'text-[13px]'}`}>
          {project.description}
        </p>

        {/* 4 — tags */}
        <div className="mt-4 flex flex-wrap gap-2">
          {project.tags.map((t) => (
            <span
              key={t}
              className="font-mono rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-white/70 transition-colors group-hover:border-white/20"
            >
              #{t}
            </span>
          ))}
        </div>

        {/* 5 — metadata */}
        <div className="mt-4 flex items-center gap-3 border-t border-white/10 pt-4 text-[11px] text-white/50">
          <span className="flex items-center gap-1.5">
            <UserRound className="h-3.5 w-3.5" style={{ color: project.accent }} />
            {project.type}
          </span>
          <span className="h-1 w-1 rounded-full bg-white/25" />
          <span className="flex items-center gap-1.5">
            <FolderGit2 className="h-3.5 w-3.5" />
            {project.category.split('/')[0].trim()}
          </span>
        </div>

        {/* 6/7 — buttons */}
        <div className="mt-5 flex flex-wrap gap-2.5 pt-1">
          <a
            href={project.link}
            target="_blank"
            rel="noreferrer"
            className={`group/btn flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r ${project.gradient} px-4 py-3 text-xs font-bold tracking-wide text-white shadow-lg transition-transform hover:scale-[1.02] active:scale-95`}
          >
            <ExternalLink className="h-3.5 w-3.5" />
            VIEW PROJECT
          </a>
          <a
            href={project.demo}
            target="_blank"
            rel="noreferrer"
            className="glass flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-xs font-bold tracking-wide text-white/90 transition-all hover:bg-white/10 active:scale-95"
          >
            <PlayCircle className="h-3.5 w-3.5" style={{ color: project.accent }} />
            LIVE DEMO
          </a>
        </div>
      </div>
    </motion.article>
  );
}

export default function Projects({ theme }: { theme: Theme }) {
  const [filter, setFilter] = useState<string>('all');
  const list = featuredProjects.filter((p) => filter === 'all' || p.group === filter);
  const big = list.filter((p) => p.featured);
  const small = list.filter((p) => !p.featured);

  return (
    <section id="work" className="relative scroll-mt-24 py-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <SectionHeading
            theme={theme}
            index="03"
            eyebrow="Real Products · 2026"
            title={<>Featured <span className="text-gradient">Projects</span></>}
            desc="Building Real Products. Learning By Creating."
          />
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass mb-12 flex w-fit flex-wrap items-center gap-1 rounded-full p-1.5"
          >
            {filters.map((f) => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`relative rounded-full px-4 py-2 text-xs font-semibold whitespace-nowrap transition-colors ${
                  filter === f.id ? 'text-white' : 'text-white/50 hover:text-white'
                }`}
              >
                {filter === f.id && (
                  <motion.span
                    layoutId="project-filter-pill"
                    className={`absolute inset-0 rounded-full bg-gradient-to-r ${theme.gradient}`}
                    transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  />
                )}
                <span className="relative z-10">{f.label}</span>
              </button>
            ))}
          </motion.div>
        </div>

        {/* PROJECT 01 & 02 — prominent, large cards */}
        <motion.div layout className="grid gap-6 lg:grid-cols-2">
          <AnimatePresence mode="popLayout">
            {big.map((p, i) => (
              <ProjectCard key={p.id} project={p} theme={theme} large index={i} />
            ))}
          </AnimatePresence>
        </motion.div>

        {/* PROJECTS 03, 04, 05 — smaller cards */}
        <motion.div layout className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {small.map((p, i) => (
              <ProjectCard key={p.id} project={p} theme={theme} large={false} index={i + 2} />
            ))}
          </AnimatePresence>
        </motion.div>

        {list.length === 0 && (
          <div className="glass rounded-3xl py-16 text-center text-white/50">
            No projects in this category yet — filtering the universe…
          </div>
        )}

        {/* more banner */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass mt-8 flex flex-col items-center justify-between gap-5 rounded-3xl p-8 text-center sm:flex-row sm:text-left"
        >
          <div className="flex items-center gap-4">
            <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${theme.gradient}`}>
              <Rocket className="h-7 w-7" />
            </div>
            <div>
              <h4 className="font-display text-xl font-bold">5 projects shipped — more on the way</h4>
              <p className="text-sm text-white/55">I build and ship new products every month, learning in public.</p>
            </div>
          </div>
          <a
            href="#contact"
            className="group flex shrink-0 items-center gap-2 rounded-full border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold transition-all hover:bg-white/10"
          >
            Start a project with me
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
