import { motion } from 'framer-motion';
import { MapPin, Mail, GraduationCap, Coffee, Award, Zap, Heart, Download } from 'lucide-react';
import SectionHeading from './SectionHeading';
import type { Theme } from '../data/portfolio';
import { services } from '../data/portfolio';

const iconMap: Record<string, React.ReactNode> = {
  globe: <span className="text-2xl">🌐</span>,
  app: <span className="text-2xl">💻</span>,
  cube: <span className="text-2xl">🧊</span>,
  zap: <span className="text-2xl">⚡</span>,
};

export default function About({ theme }: { theme: Theme }) {
  return (
    <section id="about" className="relative scroll-mt-24 py-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHeading
          theme={theme}
          index="01"
          eyebrow="About Me"
          title={<>Behind the <span className="text-gradient">pixels & polygons</span></>}
          desc="I'm a developer who thinks in systems and dreams in shaders — obsessed with the intersection of engineering rigor and cinematic design."
        />

        <div className="grid gap-8 lg:grid-cols-[0.95fr_1.05fr]">
          {/* LEFT — images + code */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.7 }}
              className="relative"
            >
              <div className="glass-strong overflow-hidden rounded-3xl p-2">
                <div className="relative flex h-64 flex-col justify-between overflow-hidden rounded-2xl p-6 sm:h-72">
                  <div
                    className="absolute inset-0 opacity-90"
                    style={{ background: `radial-gradient(circle at 80% 15%, ${theme.glow}, transparent 55%), radial-gradient(circle at 10% 90%, rgba(6,182,212,0.35), transparent 50%), linear-gradient(135deg, #140b2e, #070312)` }}
                  />
                  <div className="grid-overlay absolute inset-0 opacity-60" />
                  <div className="relative flex items-center justify-between">
                    <span className="font-mono text-[11px] tracking-[0.3em] uppercase text-white/60">◉ based in battambang</span>
                    <span className="flex h-9 w-9 items-center justify-center rounded-full border border-white/20 bg-white/5 font-mono text-xs">🇰🇭</span>
                  </div>
                  <div className="relative flex items-end justify-between">
                    <div>
                      <div className="font-display text-4xl font-bold leading-none">Gi Bunheng</div>
                      <div className="font-mono mt-2 text-sm" style={{ color: theme.secondary }}>full-stack developer</div>
                      <div className="mt-3 flex gap-2">
                        {['React', 'Node.js', 'SQL'].map((t) => (
                          <span key={t} className="glass rounded-full px-3 py-1 text-[11px]">{t}</span>
                        ))}
                      </div>
                    </div>
                    <div className="font-mono hidden text-right text-[11px] leading-5 text-white/50 sm:block">
                      lat: 13.1027° N<br />lng: 103.1982° E<br />UTC+7
                    </div>
                  </div>
                </div>
              </div>
              {/* floating badge */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="glass-strong absolute -right-3 -bottom-5 flex items-center gap-3 rounded-2xl px-5 py-4 shadow-2xl sm:-right-5"
              >
                <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${theme.gradient}`}>
                  <Award className="h-6 w-6" />
                </div>
                <div>
                  <div className="font-display text-xl font-bold">1 Year</div>
                  <div className="text-xs text-white/50">of coding & building</div>
                </div>
              </motion.div>
            </motion.div>

            {/* code window */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="glass-strong overflow-hidden rounded-3xl"
            >
              <div className="flex items-center gap-2 border-b border-white/10 px-5 py-3.5">
                <span className="h-3 w-3 rounded-full bg-rose-500" />
                <span className="h-3 w-3 rounded-full bg-amber-400" />
                <span className="h-3 w-3 rounded-full bg-emerald-400" />
                <span className="font-mono ml-3 text-xs text-white/40">developer.js — about me</span>
              </div>
              <pre className="font-mono overflow-x-auto p-5 text-[13px] leading-relaxed">
                <code>
                  <span className="text-fuchsia-400">const</span> <span className="text-cyan-300">developer</span> <span className="text-white/60">= {'{'}</span>{'\n'}
                  {'  '}name: <span className="text-emerald-300">'Gi Bunheng'</span>,{'\n'}
                  {'  '}based: <span className="text-emerald-300">'Battambang, KH'</span>,{'\n'}
                  {'  '}focus: [<span className="text-emerald-300">'3D Web'</span>, <span className="text-emerald-300">'React'</span>, <span className="text-emerald-300">'AI'</span>],{'\n'}
                  {'  '}coffee: <span className="text-amber-300">Infinity</span>,{'\n'}
                  {'  '}hireable: <span className="text-cyan-300">true</span>,{'\n'}
                  {'  '}passion: <span className="text-emerald-300">'pixels → experiences'</span>{'\n'}
                  <span className="text-white/60">{'};'}</span>
                </code>
              </pre>
            </motion.div>
          </div>

          {/* RIGHT — text */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7 }}
          >
            <h3 className="font-display text-2xl font-semibold leading-snug sm:text-3xl">
              I turn ambitious ideas into{' '}
              <span style={{ color: theme.secondary }}>fast, beautiful</span> products
              people love to use.
            </h3>
            <p className="mt-5 leading-relaxed text-white/60">
              I'm a motivated full-stack developer with 1 year of hands-on experience building
              complete web applications — from designing databases and Node.js APIs to crafting
              responsive, animated front-ends with React. My sweet spot is where <span className="text-white">clean logic meets beautiful UI</span>.
            </p>
            <p className="mt-4 leading-relaxed text-white/60">
              When I'm not pushing commits, I'm experimenting with new frameworks, solving
              coding challenges, or hunting Battambang's best iced coffee. I believe great software is <span className="text-white">solid engineering + delightful feeling</span>.
            </p>

            <div className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {[
                { icon: MapPin, label: 'Location', value: 'Battambang, Cambodia' },
                { icon: Mail, label: 'Email', value: 'Bunhenggi@gmail.com' },
                { icon: GraduationCap, label: 'Education', value: 'Information Technology' },
                { icon: Coffee, label: 'Fuel', value: 'Oat flat white ×3/day' },
              ].map((item) => (
                <div key={item.label} className="glass flex items-center gap-3 rounded-2xl px-4 py-3.5 transition-colors hover:bg-white/10">
                  <div className="glass flex h-10 w-10 shrink-0 items-center justify-center rounded-xl">
                    <item.icon className="h-[18px] w-[18px]" style={{ color: theme.secondary }} />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[11px] tracking-wider uppercase text-white/40">{item.label}</div>
                    <div className="truncate text-sm font-medium">{item.value}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <a
                href="#contact"
                className={`flex items-center gap-2 rounded-full bg-gradient-to-r ${theme.gradient} px-6 py-3 text-sm font-bold transition-transform hover:scale-105 active:scale-95`}
                style={{ boxShadow: `0 10px 32px ${theme.glow}` }}
              >
                <Heart className="h-4 w-4" /> Let's work together
              </a>
              <a href="#contact" className="glass flex items-center gap-2 rounded-full px-6 py-3 text-sm font-bold hover:bg-white/10">
                <Download className="h-4 w-4" /> My Resume
              </a>
            </div>

            <div className="mt-7 flex items-center gap-2 font-mono text-xs text-white/40">
              <Zap className="h-3.5 w-3.5" style={{ color: theme.secondary }} />
              Currently exploring: Gaussian Splatting · React 19 · AI Agents
            </div>
          </motion.div>
        </div>

        {/* services */}
        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="glass card-shine group rounded-3xl p-6 transition-all duration-300 hover:-translate-y-2"
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = theme.accent; e.currentTarget.style.boxShadow = `0 20px 50px ${theme.glow}`; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = ''; e.currentTarget.style.boxShadow = ''; }}
            >
              <div className="glass mb-4 flex h-14 w-14 items-center justify-center rounded-2xl transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6">
                {iconMap[s.icon]}
              </div>
              <h4 className="font-display text-lg font-bold">{s.title}</h4>
              <p className="mt-2 text-sm leading-relaxed text-white/55">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
