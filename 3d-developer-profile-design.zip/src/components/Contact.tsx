import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, CheckCircle2, ArrowUp, Copy, Clock } from 'lucide-react';
import SectionHeading from './SectionHeading';
import type { Theme } from '../data/portfolio';

export default function Contact({ theme }: { theme: Theme }) {
  const [form, setForm] = useState({ name: '', email: '', message: '', budget: '5k – 10k' });
  const [sent, setSent] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setForm({ name: '', email: '', message: '', budget: '5k – 10k' });
    }, 4000);
  };

  const copyEmail = () => {
    navigator.clipboard?.writeText('Bunhenggi@gmail.com');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="contact" className="relative scroll-mt-24 py-24 pb-12">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHeading
          theme={theme}
          index="05"
          eyebrow="Get In Touch"
          title={<>Let's build something <span className="text-gradient">extraordinary</span></>}
          desc="Have a project in mind? My inbox is always open — I usually reply within 24 hours."
        />

        <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          {/* info */}
          <div className="space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${theme.gradient} p-[1.5px]`}
            >
              <div className="rounded-3xl bg-[#0a0618]/95 p-7">
                <div className="flex items-center gap-2 font-mono text-xs text-emerald-300">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="absolute h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                    <span className="relative h-2.5 w-2.5 rounded-full bg-emerald-400" />
                  </span>
                  AVAILABLE FOR NEW PROJECTS
                </div>
                <h3 className="font-display mt-3 text-2xl font-bold leading-snug">
                  Currently booking<br />Q1 2026 projects
                </h3>
                <div className="mt-4 flex items-center gap-2 text-sm text-white/60">
                  <Clock className="h-4 w-4" /> Avg. response time: 6 hours
                </div>
                <button
                  onClick={copyEmail}
                  className="glass mt-5 flex w-full items-center justify-between rounded-2xl px-4 py-3.5 font-mono text-sm transition-colors hover:bg-white/10"
                >
                  <span className="flex items-center gap-2.5">
                    <Mail className="h-4 w-4" style={{ color: theme.secondary }} />
                    Bunhenggi@gmail.com
                  </span>
                  {copied ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4 opacity-50" />}
                </button>
                {copied && <p className="mt-2 text-center font-mono text-xs text-emerald-300">✓ Email copied to clipboard!</p>}
              </div>
            </motion.div>

            {[
              { icon: Phone, label: 'Phone / Telegram', value: '+855 969751104' },
              { icon: MapPin, label: 'Location', value: 'Battambang, Cambodia · Remote' },
            ].map((c, i) => (
              <motion.div
                key={c.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 + i * 0.08 }}
                className="glass flex items-center gap-4 rounded-2xl px-5 py-4 transition-colors hover:bg-white/[0.08]"
              >
                <div className="glass flex h-12 w-12 items-center justify-center rounded-xl">
                  <c.icon className="h-5 w-5" style={{ color: theme.secondary }} />
                </div>
                <div>
                  <div className="text-[11px] tracking-wider uppercase text-white/40">{c.label}</div>
                  <div className="font-medium">{c.value}</div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* form */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="glass-strong rounded-3xl p-7 sm:p-9"
          >
            {sent ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex min-h-[420px] flex-col items-center justify-center text-center"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 14 }}
                  className="flex h-20 w-20 items-center justify-center rounded-full bg-emerald-400/15"
                >
                  <CheckCircle2 className="h-10 w-10 text-emerald-400" />
                </motion.div>
                <h3 className="font-display mt-6 text-2xl font-bold">Message sent! 🚀</h3>
                <p className="mt-2 max-w-sm text-white/55">
                  Thanks for reaching out, {form.name || 'friend'}. I'll get back to you within 24 hours.
                </p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label className="font-mono mb-2 block text-xs tracking-widest uppercase text-white/50">Your name *</label>
                    <input
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="John Doe"
                      className="w-full rounded-2xl border border-white/10 bg-white/5 px-5 py-3.5 text-sm outline-none transition-all placeholder:text-white/25 focus:border-white/25 focus:bg-white/[0.08]"
                    />
                  </div>
                  <div>
                    <label className="font-mono mb-2 block text-xs tracking-widest uppercase text-white/50">Email *</label>
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="john@company.com"
                      className="w-full rounded-2xl border border-white/10 bg-white/5 px-5 py-3.5 text-sm outline-none transition-all placeholder:text-white/25 focus:border-white/25 focus:bg-white/[0.08]"
                    />
                  </div>
                </div>
                <div>
                  <label className="font-mono mb-2 block text-xs tracking-widest uppercase text-white/50">Project budget</label>
                  <div className="flex flex-wrap gap-2">
                    {['< 5k', '5k – 10k', '10k – 25k', '25k+'].map((b) => (
                      <button
                        key={b}
                        type="button"
                        onClick={() => setForm({ ...form, budget: b })}
                        className={`rounded-full px-5 py-2.5 font-mono text-xs font-bold transition-all ${
                          form.budget === b
                            ? `bg-gradient-to-r ${theme.gradient} text-white shadow-lg`
                            : 'border border-white/10 bg-white/5 text-white/50 hover:text-white'
                        }`}
                      >
                        ${b}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="font-mono mb-2 block text-xs tracking-widest uppercase text-white/50">Tell me about your project *</label>
                  <textarea
                    required
                    rows={5}
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="I want to build an immersive 3D product site for my brand..."
                    className="w-full resize-none rounded-2xl border border-white/10 bg-white/5 px-5 py-3.5 text-sm outline-none transition-all placeholder:text-white/25 focus:border-white/25 focus:bg-white/[0.08]"
                  />
                </div>
                <button
                  type="submit"
                  className={`group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r ${theme.gradient} px-6 py-4 text-sm font-bold tracking-wide transition-transform hover:scale-[1.01] active:scale-[0.99]`}
                  style={{ boxShadow: `0 12px 40px ${theme.glow}` }}
                >
                  SEND MESSAGE
                  <Send className="h-4 w-4 transition-transform group-hover:translate-x-1 group-hover:-translate-y-0.5" />
                </button>
                <p className="text-center font-mono text-[11px] text-white/30">
                  No spam, no sharing your data. Just a friendly reply. 🤝
                </p>
              </form>
            )}
          </motion.div>
        </div>

        {/* footer */}
        <footer className="mt-20 border-t border-white/10 pt-8">
          <div className="flex flex-col items-center justify-between gap-5 sm:flex-row">
            <div className="flex items-center gap-3">
              <div className={`flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br ${theme.gradient} font-mono text-sm font-bold`}>
                {'</>'}
              </div>
              <div className="text-sm">
                <span className="font-display font-bold">gi.bunheng</span>
                <span className="text-white/40"> — crafted with React, Node.js & ☕</span>
              </div>
            </div>
            <p className="font-mono text-xs text-white/35">© 2026 Gi Bunheng. All rights reserved.</p>
            <a
              href="#home"
              className="glass group flex h-11 w-11 items-center justify-center rounded-full transition-all hover:-translate-y-1"
              aria-label="Back to top"
            >
              <ArrowUp className="h-4 w-4 transition-transform group-hover:-translate-y-0.5" />
            </a>
          </div>
        </footer>
      </div>
    </section>
  );
}
