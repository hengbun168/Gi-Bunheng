import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Terminal, ArrowUpRight } from 'lucide-react';
import type { Theme } from '../data/portfolio';

const links = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'skills', label: 'Skills' },
  { id: 'work', label: 'Work' },
  { id: 'experience', label: 'Journey' },
  { id: 'contact', label: 'Contact' },
];

export default function Navbar({ theme, active }: { theme: Theme; active: string }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? 'py-3' : 'py-5'
        }`}
      >
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div
            className={`flex items-center justify-between rounded-2xl px-4 py-3 transition-all duration-500 ${
              scrolled ? 'glass-strong shadow-2xl shadow-black/40' : 'bg-transparent border border-transparent'
            }`}
          >
            <a href="#home" className="group flex items-center gap-3">
              <div
                className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${theme.gradient} shadow-lg transition-transform duration-300 group-hover:rotate-12 group-hover:scale-110`}
                style={{ boxShadow: `0 8px 30px ${theme.glow}` }}
              >
                <Terminal className="h-5 w-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="leading-none">
                <span className="font-display text-lg font-700 font-bold tracking-tight">gi.bunheng</span>
                <span className="font-mono block text-[10px] tracking-[0.25em] uppercase opacity-60">full-stack dev</span>
              </div>
            </a>

            <nav className="hidden items-center gap-1 lg:flex">
              {links.map((l) => (
                <a
                  key={l.id}
                  href={`#${l.id}`}
                  className={`relative rounded-full px-4 py-2 font-mono text-[13px] tracking-wide transition-all duration-300 ${
                    active === l.id ? 'text-white' : 'text-white/55 hover:text-white'
                  }`}
                >
                  {active === l.id && (
                    <motion.span
                      layoutId="nav-pill"
                      className="absolute inset-0 rounded-full border border-white/15 bg-white/10"
                      transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                    />
                  )}
                  <span className="relative z-10">
                    <span style={{ color: active === l.id ? theme.secondary : undefined }} className="mr-1 opacity-80">/</span>
                    {l.label}
                  </span>
                </a>
              ))}
            </nav>

            <div className="hidden items-center gap-3 lg:flex">
              <div className="font-mono hidden items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1.5 text-[11px] text-emerald-300 xl:flex">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                OPEN TO WORK
              </div>
              <a
                href="#contact"
                className={`group flex items-center gap-1.5 rounded-full bg-gradient-to-r ${theme.gradient} px-5 py-2.5 text-sm font-semibold text-white shadow-lg transition-transform hover:scale-105 active:scale-95`}
                style={{ boxShadow: `0 8px 28px ${theme.glow}` }}
              >
                Hire Me
                <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </div>

            <button
              onClick={() => setOpen(!open)}
              className="glass flex h-10 w-10 items-center justify-center rounded-xl lg:hidden"
              aria-label="Toggle menu"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-x-4 top-24 z-50 lg:hidden"
          >
            <div className="glass-strong rounded-2xl p-4 shadow-2xl">
              {links.map((l, i) => (
                <motion.a
                  key={l.id}
                  href={`#${l.id}`}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={`flex items-center justify-between rounded-xl px-4 py-3 font-display text-lg font-medium ${
                    active === l.id ? 'bg-white/10 text-white' : 'text-white/70'
                  }`}
                >
                  <span>
                    <span className="font-mono mr-2 text-xs opacity-50">0{i + 1}</span>
                    {l.label}
                  </span>
                  <ArrowUpRight className="h-4 w-4 opacity-40" />
                </motion.a>
              ))}
              <a
                href="#contact"
                onClick={() => setOpen(false)}
                className={`mt-3 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r ${theme.gradient} px-4 py-3 font-semibold`}
              >
                Hire Me <ArrowUpRight className="h-4 w-4" />
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
