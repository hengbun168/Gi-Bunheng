import { motion } from 'framer-motion';
import { Briefcase, GraduationCap, Trophy, Languages } from 'lucide-react';
import SectionHeading from './SectionHeading';
import { experience, type Theme } from '../data/portfolio';

export default function Experience({ theme }: { theme: Theme }) {
  return (
    <section id="experience" className="relative scroll-mt-24 py-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHeading
          theme={theme}
          index="04"
          eyebrow="Career Journey"
          title={<>Experience & <span className="text-gradient">milestones</span></>}
          desc="Six years of shipping, learning and leading — from freelance hustle to creative tech lead."
        />

        <div className="grid gap-8 lg:grid-cols-[1.3fr_0.7fr]">
          {/* timeline */}
          <div className="relative">
            <div className="absolute top-2 bottom-8 left-[19px] w-px bg-gradient-to-b from-white/20 via-white/10 to-transparent sm:left-[23px]" />
            <motion.div
              initial={{ scaleY: 0 }}
              whileInView={{ scaleY: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.4, ease: 'easeInOut' }}
              className="absolute top-2 bottom-8 left-[19px] w-px origin-top sm:left-[23px]"
              style={{ background: `linear-gradient(180deg, ${theme.accent}, ${theme.secondary})` }}
            />

            <div className="space-y-5">
              {experience.map((job, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-60px' }}
                  transition={{ duration: 0.6, delay: i * 0.08 }}
                  className="relative pl-14 sm:pl-16"
                >
                  <div
                    className="absolute top-5 left-2.5 flex h-9 w-9 items-center justify-center rounded-full border sm:left-[9px]"
                    style={{
                      background: job.current ? theme.accent : 'rgba(255,255,255,0.06)',
                      borderColor: job.current ? theme.accent : 'rgba(255,255,255,0.15)',
                      boxShadow: job.current ? `0 0 24px ${theme.glow}` : 'none',
                    }}
                  >
                    <Briefcase className="h-4 w-4" />
                    {job.current && (
                      <span className="absolute inset-0 animate-ping rounded-full opacity-30" style={{ background: theme.accent }} />
                    )}
                  </div>

                  <div className="glass card-shine rounded-3xl p-6 transition-all duration-300 hover:bg-white/[0.08]">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className="font-mono rounded-full px-3 py-1 text-[11px] font-bold"
                        style={{ background: `${theme.accent}20`, color: theme.secondary, border: `1px solid ${theme.accent}40` }}
                      >
                        {job.period}
                      </span>
                      {job.current && (
                        <span className="rounded-full bg-emerald-400/15 px-3 py-1 font-mono text-[11px] font-bold text-emerald-300">
                          ● CURRENT
                        </span>
                      )}
                    </div>
                    <h3 className="font-display mt-3 text-xl font-bold">{job.role}</h3>
                    <p className="font-mono text-sm" style={{ color: theme.secondary }}>{job.company}</p>
                    <p className="mt-3 text-sm leading-relaxed text-white/55">{job.description}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {job.tags.map((t) => (
                        <span key={t} className="rounded-lg bg-white/5 px-2.5 py-1 text-[11px] text-white/60 ring-1 ring-white/10">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* side cards */}
          <div className="space-y-5">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="glass-strong rounded-3xl p-6"
            >
              <div className="flex items-center gap-3">
                <div className={`flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${theme.gradient}`}>
                  <GraduationCap className="h-5 w-5" />
                </div>
                <h4 className="font-display text-lg font-bold">Education</h4>
              </div>
              <div className="mt-5 space-y-4">
                <div className="border-l-2 pl-4" style={{ borderColor: theme.accent }}>
                  <div className="text-sm font-bold">B.Sc. Information Technology</div>
                  <div className="font-mono text-xs text-white/50">University in Battambang · 2022 — Present</div>
                  <div className="mt-1 text-xs text-white/60">Focus: web development, databases, networking & software engineering.</div>
                </div>
                <div className="border-l-2 border-white/10 pl-4">
                  <div className="text-sm font-bold">Full-Stack Web Development Bootcamp</div>
                  <div className="font-mono text-xs text-white/50">Battambang · 2024 — 2025</div>
                </div>
                <div className="border-l-2 border-white/10 pl-4">
                  <div className="text-sm font-bold">JavaScript Algorithms & Data Structures</div>
                  <div className="font-mono text-xs text-white/50">freeCodeCamp · 2024</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="glass-strong rounded-3xl p-6"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500">
                  <Trophy className="h-5 w-5" />
                </div>
                <h4 className="font-display text-lg font-bold">Milestones</h4>
              </div>
              <ul className="mt-4 space-y-3 text-sm">
                {[
                  ['🎓 Bootcamp graduate with honors', '2025'],
                  ['🚀 Shipped first 5 projects', '2025'],
                  ['📜 JavaScript certification', '2024'],
                  ['🌱 Started my CS degree', '2022'],
                ].map(([t, d]) => (
                  <li key={t} className="flex items-start justify-between gap-3">
                    <span className="text-white/75">{t}</span>
                    <span className="font-mono shrink-0 text-[11px] text-white/40">{d}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.15 }}
              className="glass-strong rounded-3xl p-6"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600">
                  <Languages className="h-5 w-5" />
                </div>
                <h4 className="font-display text-lg font-bold">Languages</h4>
              </div>
              <div className="mt-4 space-y-3">
                {[
                  ['Khmer', 'Native', 100],
                  ['English', 'Working · B2', 70],
                ].map(([lang, lvl, pct]) => (
                  <div key={lang as string}>
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{lang}</span>
                      <span className="font-mono text-xs text-white/40">{lvl}</span>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${pct}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        className={`h-full rounded-full bg-gradient-to-r ${theme.gradient}`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
