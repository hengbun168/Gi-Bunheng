import { useEffect, useRef, useState } from 'react';
import { Camera, UploadCloud, Trash2, Loader2 } from 'lucide-react';
import { getStoredPhoto, storePhotoFile, clearPhoto, subscribePhoto } from '../utils/profilePhoto';

/**
 * Profile photo resolution order:
 *  1. Photo uploaded in the browser (saved in localStorage)
 *  2. Real screenshot at /images/profile.jpg  (drop the file in /public)
 *  3. Elegant GB monogram fallback (click it to upload a photo)
 */
export default function Avatar({ className = '' }: { className?: string }) {
  const [stored, setStored] = useState<string | null>(null);
  const [remoteFailed, setRemoteFailed] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setStored(getStoredPhoto());
    return subscribePhoto(() => {
      setStored(getStoredPhoto());
      setRemoteFailed(false);
      setSaving(false);
    });
  }, []);

  const handleFile = async (file?: File | null) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please choose an image file');
      return;
    }
    setError('');
    setSaving(true);
    try {
      await storePhotoFile(file);
    } catch {
      setSaving(false);
      setError('Could not read that image');
    }
  };

  const hasPhoto = Boolean(stored) || (!stored && !remoteFailed);
  const photoSrc = stored ?? '/images/profile.jpg';

  return (
    <div
      className={`group/avt relative h-full w-full overflow-hidden ${className}`}
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        handleFile(e.dataTransfer.files?.[0]);
      }}
    >
      {/* THE PHOTO */}
      {stored ? (
        <img src={stored} alt="Gi Bunheng — Full-Stack Developer" className="h-full w-full object-cover object-[center_18%]" />
      ) : !remoteFailed ? (
        <img
          src={photoSrc}
          alt="Gi Bunheng — Full-Stack Developer"
          onError={() => setRemoteFailed(true)}
          className="h-full w-full object-cover object-[center_18%]"
        />
      ) : (
        /* MONOGRAM FALLBACK — also the upload dropzone */
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-violet-700 via-fuchsia-700 to-cyan-600 px-6 text-center transition-colors hover:from-violet-600 hover:to-cyan-500"
        >
          <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(circle_at_30%_20%,white,transparent_45%)]" />
          <span className="font-display relative text-8xl font-bold tracking-tight drop-shadow-xl">GB</span>
          <span className="font-mono relative mt-3 text-sm tracking-[0.25em] uppercase text-white/90">Gi Bunheng</span>

          <span
            className={`relative mt-6 flex items-center gap-2 rounded-full px-4 py-2.5 font-mono text-[11px] font-bold transition-all ${
              dragging ? 'scale-110 bg-white text-fuchsia-700' : 'glass text-white'
            }`}
          >
            {dragging ? <UploadCloud className="h-4 w-4" /> : <Camera className="h-4 w-4" />}
            {dragging ? 'DROP TO ADD PHOTO' : 'CLICK TO ADD YOUR PHOTO'}
          </span>
          <span className="relative mt-2 font-mono text-[10px] text-white/60">or drag &amp; drop a JPG / PNG here</span>
          {error && <span className="relative mt-2 text-[11px] font-semibold text-rose-200">{error}</span>}
        </button>
      )}

      {/* HOVER CONTROLS when a photo is present */}
      {hasPhoto && !saving && (
        <div className="absolute inset-0 z-30 flex items-center justify-center gap-3 bg-black/55 opacity-0 backdrop-blur-[2px] transition-opacity duration-300 group-hover/avt:opacity-100">
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="flex items-center gap-2 rounded-full bg-white px-4 py-2.5 text-xs font-bold text-slate-900 shadow-xl transition-transform hover:scale-105 active:scale-95"
          >
            <Camera className="h-4 w-4" /> Change photo
          </button>
          {stored && (
            <button
              type="button"
              onClick={() => clearPhoto()}
              aria-label="Remove uploaded photo"
              className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white ring-1 ring-white/25 transition-colors hover:bg-rose-500/80"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>
      )}

      {saving && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-2 bg-black/70">
          <Loader2 className="h-8 w-8 animate-spin text-cyan-300" />
          <span className="font-mono text-xs text-white/80">Saving photo…</span>
        </div>
      )}

      {/* drag ring */}
      {dragging && (
        <div className="pointer-events-none absolute inset-2 z-40 rounded-2xl border-2 border-dashed border-white/80 bg-white/10" />
      )}

      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/jpg,image/webp"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
    </div>
  );
}
