/* Profile photo storage utilities.
   Uploaded photos are resized in the browser and saved as a JPEG
   data-URL in localStorage, so they persist across reloads without
   needing a server or touching the project files. */

const KEY = 'gb_profile_photo_v1';
const EVENT = 'gb-profile-photo-changed';

export function getStoredPhoto(): string | null {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

export function subscribePhoto(cb: () => void): () => void {
  const handler = () => cb();
  window.addEventListener(EVENT, handler);
  return () => window.removeEventListener(EVENT, handler);
}

function emit() {
  window.dispatchEvent(new Event(EVENT));
}

export function clearPhoto() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
  emit();
}

function fileToDataURL(file: File, maxSize = 720, quality = 0.88): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('read failed'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('invalid image'));
      img.onload = () => {
        let { width, height } = img;
        if (width >= height && width > maxSize) {
          height = Math.round((height * maxSize) / width);
          width = maxSize;
        } else if (height > maxSize) {
          width = Math.round((width * maxSize) / height);
          height = maxSize;
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(reader.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}

export async function storePhotoFile(file: File): Promise<void> {
  const data = await fileToDataURL(file);
  try {
    localStorage.setItem(KEY, data);
  } catch {
    /* storage might be full — photo still works for the session via event */
  }
  emit();
}
