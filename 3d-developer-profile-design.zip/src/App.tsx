import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Scene3D from './components/Scene3D';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Contact from './components/Contact';
import BackgroundControls from './components/BackgroundControls';
import { themes, type Theme } from './data/portfolio';

function Loader({ theme }: { theme: Theme }) {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => Math.min(p + Math.random() * 22, 100));
    }, 180);
    return () => clearInterval(interval);
  }, []);
  return (
    <motion.div
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.6 }}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center"
      style={{ background: theme.bg }}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className={`flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br ${theme.gradient} font-mono text-2xl font-bold shadow-2xl`}
        style={{ boxShadow: `0 0 60px ${theme.glow}` }}
      >
        {'</>'}
      </motion.div>
      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="font-display mt-6 text-2xl font-bold tracking-tight"
      >
        gi.bunheng<span style={{ color: theme.secondary }}>.dev</span>
      </motion.h1>
      <p className="font-mono mt-2 text-xs tracking-[0.3em] text-white/40 uppercase">Initializing 3D universe</p>
      <div className="mt-6 h-1.5 w-56 overflow-hidden rounded-full bg-white/10">
        <motion.div
          className={`h-full rounded-full bg-gradient-to-r ${theme.gradient}`}
          style={{ width: `${progress}%`, transition: 'width 0.2s ease' }}
        />
      </div>
      <p className="font-mono mt-3 text-xs" style={{ color: theme.secondary }}>{Math.round(progress)}%</p>
    </motion.div>
  );
}

function CursorGlow({ theme }: { theme: Theme }) {
  const [pos, setPos] = useState({ x: -500, y: -500 });
  useEffect(() => {
    const move = (e: MouseEvent) => setPos({ x: e.clientX, y: e.clientY });
    window.addEventListener('mousemove', move, { passive: true });
    return () => window.removeEventListener('mousemove', move);
  }, []);
  return (
    <div
      className="pointer-events-none fixed z-[5] hidden h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-25 blur-[120px] transition-[background] duration-700 md:block"
      style={{
        left: pos.x,
        top: pos.y,
        background: `radial-gradient(circle, ${theme.accent} 0%, ${theme.secondary} 40%, transparent 70%)`,
      }}
    />
  );
}

export default function App() {
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState<Theme>(themes[0]);
  const [autoRotate, setAutoRotate] = useState(true);
  const [showParticles, setShowParticles] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [active, setActive] = useState('home');

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2200);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const sections = ['home', 'about', 'skills', 'work', 'experience', 'contact'];
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: '-40% 0px -55% 0px' }
    );
    sections.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [loading]);

  // update body bg on theme change
  useEffect(() => {
    document.body.style.background = theme.bg;
  }, [theme]);

  return (
    <div className="relative min-h-screen text-white antialiased" style={{ transition: 'background 1s ease' }}>
      <AnimatePresence>{loading && <Loader theme={theme} />}</AnimatePresence>

      <Scene3D theme={theme} autoRotate={autoRotate} showParticles={showParticles} speed={speed} />
      <CursorGlow theme={theme} />
      <div className="noise-overlay pointer-events-none fixed inset-0 z-[6] opacity-60" />

      {/* side progress rail */}
      <div className="fixed top-1/2 left-4 z-40 hidden -translate-y-1/2 flex-col items-center gap-3 xl:flex">
        {['home', 'about', 'skills', 'work', 'experience', 'contact'].map((id, i) => (
          <a key={id} href={`#${id}`} className="group flex items-center gap-2" aria-label={id}>
            <span className="font-mono text-[10px] opacity-0 transition-opacity group-hover:opacity-60">0{i + 1}</span>
            <span
              className="block rounded-full transition-all duration-300"
              style={{
                width: 4,
                height: active === id ? 32 : 12,
                background: active === id ? theme.secondary : 'rgba(255,255,255,0.2)',
                boxShadow: active === id ? `0 0 12px ${theme.glow}` : 'none',
              }}
            />
          </a>
        ))}
      </div>

      <Navbar theme={theme} active={active} />

      <main className="relative z-10">
        <Hero theme={theme} />
        <About theme={theme} />
        <Skills theme={theme} />
        <Projects theme={theme} />
        <Experience theme={theme} />
        <Contact theme={theme} />
      </main>

      <BackgroundControls
        theme={theme}
        setTheme={setTheme}
        autoRotate={autoRotate}
        setAutoRotate={setAutoRotate}
        showParticles={showParticles}
        setShowParticles={setShowParticles}
        speed={speed}
        setSpeed={setSpeed}
      />
    </div>
  );
}
